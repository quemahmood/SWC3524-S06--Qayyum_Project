import java.util.*;

public class MaritimeReliefRouteOptimization {

    // Distance Matrix (Adjacency Matrix)
    static int[][] distanceMatrix = {
        {0, 15, 25, 35},
        {15, 0, 30, 28},
        {25, 30, 0, 20},
        {35, 28, 20, 0}
    };

    // Location names
    static String[] locations = {"Port A", "Port B", "Relief Center C", "Relief Center D"};

    public static void main(String[] args) {
        // Backtracking TSP
        System.out.println(backtrackingTSP(distanceMatrix));

        // Heap Example
        System.out.println("\n--- Min-Heap Example ---");
        MinHeap heap = new MinHeap();
        heap.insert(10);
        heap.insert(5);
        heap.insert(15);
        System.out.println("Min element: " + heap.getMin());
        System.out.println("Extract min: " + heap.extractMin());
        System.out.println("Next min: " + heap.getMin());

        // Splay Tree Example
        System.out.println("\n--- Splay Tree Example ---");
        SplayTree tree = new SplayTree();
        tree.insert(20);
        tree.insert(10);
        tree.insert(30);
        System.out.println("Search 10: " + tree.search(10));
        System.out.println("Search 40: " + tree.search(40));
    }

    // ================= Backtracking TSP =================
    public static String backtrackingTSP(int[][] dist) {
        int n = dist.length;
        boolean[] visited = new boolean[n];
        visited[0] = true; // Start from Port A
        StringBuilder path = new StringBuilder("Port A");
        Result result = new Result();
        result.minCost = Integer.MAX_VALUE;

        tspBacktracking(0, dist, visited, n, 1, 0, path, result);

        return "Backtracking TSP Route: " + result.path + " | Total Distance: " + result.minCost + " nm";
    }

    static class Result {
        int minCost;
        String path;
    }

    private static void tspBacktracking(int pos, int[][] dist, boolean[] visited, int n, int count, int cost, StringBuilder path, Result result) {
        if (count == n) {
            cost += dist[pos][0]; // complete cycle
            String finalPath = path.toString() + " -> Port A";
            if (cost < result.minCost) {
                result.minCost = cost;
                result.path = finalPath;
            }
            return;
        }

        for (int i = 0; i < n; i++) {
            if (!visited[i]) {
                visited[i] = true;
                int originalLength = path.length();
                path.append(" -> ").append(locations[i]);
                tspBacktracking(i, dist, visited, n, count + 1, cost + dist[pos][i], path, result);
                visited[i] = false; // backtrack
                path.setLength(originalLength);
            }
        }
    }

    // ================= Min-Heap Implementation =================
    static class MinHeap {
        private ArrayList<Integer> heap = new ArrayList<>();

        public void insert(int val) {
            heap.add(val);
            heapifyUp(heap.size() - 1);
        }

        public int extractMin() {
            if (heap.size() == 0) return -1;
            int min = heap.get(0);
            int last = heap.remove(heap.size() - 1);
            if (heap.size() > 0) {
                heap.set(0, last);
                heapifyDown(0);
            }
            return min;
        }

        public int getMin() {
            return heap.size() > 0 ? heap.get(0) : -1;
        }

        private void heapifyUp(int index) {
            while (index > 0) {
                int parent = (index - 1) / 2;
                if (heap.get(parent) > heap.get(index)) {
                    int temp = heap.get(parent);
                    heap.set(parent, heap.get(index));
                    heap.set(index, temp);
                    index = parent;
                } else break;
            }
        }

        private void heapifyDown(int index) {
            int left, right, smallest;
            while (true) {
                left = 2 * index + 1;
                right = 2 * index + 2;
                smallest = index;
                if (left < heap.size() && heap.get(left) < heap.get(smallest)) smallest = left;
                if (right < heap.size() && heap.get(right) < heap.get(smallest)) smallest = right;
                if (smallest != index) {
                    int temp = heap.get(index);
                    heap.set(index, heap.get(smallest));
                    heap.set(smallest, temp);
                    index = smallest;
                } else break;
            }
        }
    }

    // ================= Splay Tree Implementation =================
    static class SplayTree {
        class Node {
            int key;
            Node left, right;

            Node(int key) { this.key = key; }
        }

        private Node root;

        public void insert(int key) {
            root = insert(root, key);
            root = splay(root, key);
        }

        private Node insert(Node node, int key) {
            if (node == null) return new Node(key);
            if (key < node.key) node.left = insert(node.left, key);
            else if (key > node.key) node.right = insert(node.right, key);
            return node;
        }

        public boolean search(int key) {
            root = splay(root, key);
            return root != null && root.key == key;
        }

        private Node splay(Node node, int key) {
            if (node == null || node.key == key) return node;

            if (key < node.key) {
                if (node.left == null) return node;
                if (key < node.left.key) {
                    node.left.left = splay(node.left.left, key);
                    node = rotateRight(node);
                } else if (key > node.left.key) {
                    node.left.right = splay(node.left.right, key);
                    if (node.left.right != null) node.left = rotateLeft(node.left);
                }
                return node.left == null ? node : rotateRight(node);
            } else {
                if (node.right == null) return node;
                if (key > node.right.key) {
                    node.right.right = splay(node.right.right, key);
                    node = rotateLeft(node);
                } else if (key < node.right.key) {
                    node.right.left = splay(node.right.left, key);
                    if (node.right.left != null) node.right = rotateRight(node.right);
                }
                return node.right == null ? node : rotateLeft(node);
            }
        }

        private Node rotateRight(Node y) {
            Node x = y.left;
            y.left = x.right;
            x.right = y;
            return x;
        }

        private Node rotateLeft(Node x) {
            Node y = x.right;
            x.right = y.left;
            y.left = x;
            return y;
        }
    }
}
